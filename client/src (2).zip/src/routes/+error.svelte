<main>
    <h1>404</h1>
    <p>走丢了吗，点击<a href="/main">这里</a>回首页吧</p>
</main>

<style>
    h1 {
        font-size: 4em;
        text-align: center;
        margin-top: 5vh;
    }

    a {
        color: #007bff;
    }

    a:hover {
        text-decoration: none;
        color: #0056b3;
    }

    main {
        text-align: center;

    }

    p {
        margin-top: 5vh;
        font-size: 1.5em;
    }
</style>
