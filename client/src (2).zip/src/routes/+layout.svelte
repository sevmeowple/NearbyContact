<script lang="ts">
    import '../app.postcss';
</script>

<slot/>
