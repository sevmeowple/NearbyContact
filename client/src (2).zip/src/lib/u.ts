// 这里写一些常量
const serverUrl = 'http://localhost:8030';

export {serverUrl};